<footer class="navbar navbar-expand-lg navbar-dark bg-primary footer">
    <div class="container d-flex flex-column align-items-center">
        <div class="footer-info text-center">
            <p style="font-weight: bold; margin: auto;">HappyHolidayHome
                <br>Made with ❤️ by Adhiraj Saha
            </p>
            <br>
            <p>Connect with me on:</p>
            <a href="https://www.linkedin.com/in/adhirajsaha" target="_blank" rel="noopener noreferrer">
                <i class="fa-brands fa-2x fa-linkedin" style="color: #ffffff;"></i>
            </a>
            &nbsp;
            <a href="https://github.com/adhirajcs" target="_blank" rel="noopener noreferrer">
                <i class="fa-brands fa-2x fa-github" style="color: #ffffff;"></i>
            </a>
        </div>
    </div>
</footer>