<div id="sidebar" class="sidebar">
    <div class="sidebar-content">
        <ul class="nav flex-column">
            <li class="nav-item">
                <div class="d-flex justify-content-end">
                    <a class="navbar-brand" href="../index.php">
                        <img src="../assets/img/logo.jpg" alt="HappyHolidayHome" class="website-icon" style="max-width: 150px;">
                    </a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="admwin_dashboard.php">
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_holidayhomes.php">
                    Holiday Homes
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_users.php">
                    Users
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_reservations.php">
                    Reservations
                </a>
            </li>
        </ul>
    </div>
</div>