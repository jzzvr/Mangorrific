<footer class="footer">
    <div class="footer-content">
        <a href="../index.php">
            <img src="../assets/img/logo.jpg" alt="Logo" style="width: 100px; height: auto;">
        </a>
        <div class="footer-links">
            <a href="../index.php">Home</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
        </div>
    </div>
    <div class="footer-info">
        <p>HappyHolidayHome</p>
        <br>
        <p>Made with ❤️ by Adhiraj Saha</p>
        <br>
        <p>Connect with me on:</p>
        <br>
        <a href="https://www.linkedin.com/in/adhirajsaha" target="_blank" rel="noopener noreferrer">
            <i class="fa-brands fa-2x fa-linkedin" style="color: #ffffff;"></i>
        </a>
        &nbsp;
        <a href="https://github.com/adhirajcs" target="_blank" rel="noopener noreferrer">
            <i class="fa-brands fa-2x fa-github" style="color: #ffffff;"></i>
        </a>
    </div>
</footer>